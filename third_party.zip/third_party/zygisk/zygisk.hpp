/* Copyright 2021-2023 John "topjohnwu" Wu
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */
#pragma once

#include <jni.h>
#include <sys/types.h>
#include <cstdint>
#include <string_view>

namespace zygisk {

struct Api;
struct AppSpecializeArgs;
struct ServerSpecializeArgs;

class ModuleBase {
public:
    virtual void onLoad(Api *api, JNIEnv *env) {}
    virtual void preAppSpecialize(AppSpecializeArgs *args) {}
    virtual void postAppSpecialize(const AppSpecializeArgs *args) {}
    virtual void preServerSpecialize(ServerSpecializeArgs *args) {}
    virtual void postServerSpecialize(const ServerSpecializeArgs *args) {}
};

struct AppSpecializeArgs {
    jstring nice_name;
    jstring app_data_dir;
    const char *const *args;
    jint *uid;
    jint *gid;
    jintArray *gids;
    jint *runtime_flags;
    jobjectArray *rlimits;
    jstring *instruction_set;
    const char *const *app_path;
    jstring *app_lib_dir;
    const char *const *permitted_paths;
    jint *mount_external;
    jstring *se_info;
    jstring *nice_name_val;
};

struct ServerSpecializeArgs {
    jint *uid;
    jint *gid;
    jintArray *gids;
    jint *runtime_flags;
    jlong *permitted_capabilities;
    jlong *effective_capabilities;
};

struct Api {
    void connectCompanion(int pid);
    void connectCompanion();
    int getModuleDir();
    void setOption(int opt);
    void pltHookRegister(std::string_view regex, std::string_view symbol, void *hook, void **backup);
    void pltHookCommit();
    bool exemptFd(int fd);
    enum Option { DLCLOSE_MODULE_LIBRARY = 0 };
};

#define REGISTER_ZYGISK_MODULE(cls) \
    extern "C" __attribute__((visibility("default"))) void zygisk_module_entry(zygisk::Api *api, JNIEnv *env) { \
        static cls module; \
        module.onLoad(api, env); \
        api->setOption(zygisk::Api::Option::DLCLOSE_MODULE_LIBRARY); \
    }

#define REGISTER_ZYGISK_COMPANION(func) \
    extern "C" __attribute__((visibility("default"))) void zygisk_companion_entry(int client) { \
        func(client); \
    }

} // namespace zygisk